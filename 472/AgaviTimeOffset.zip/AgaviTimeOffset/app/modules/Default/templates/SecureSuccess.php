<html>
	<head>
		<title>Permission Denied</title>
	</head>
	<body>
		<h1>Permission Denied</h1>
		<p>You do not have sufficient credentials to access this page.</p>
	</body>
</html>