<?php

class Default_UnavailableAction extends AgaviAction
{
	public function getDefaultViewName()
	{
		return 'Success';
	}
}

?>