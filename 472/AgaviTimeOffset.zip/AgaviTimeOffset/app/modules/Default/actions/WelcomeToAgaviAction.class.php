<?php

class Default_WelcomeToAgaviAction extends AgaviAction
{
	public function getDefaultViewName()
	{
		return 'Success';
	}
}

?>