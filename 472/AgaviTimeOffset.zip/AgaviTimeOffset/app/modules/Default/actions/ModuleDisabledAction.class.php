<?php

class Default_ModuleDisabledAction extends AgaviAction
{
	public function getDefaultViewName()
	{
		return 'Success';
	}
}

?>