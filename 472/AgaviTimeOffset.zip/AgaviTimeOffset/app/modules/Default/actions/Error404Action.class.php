<?php

class Default_Error404Action extends AgaviAction
{
	public function getDefaultViewName()
	{
		return 'Success';
	}
}

?>