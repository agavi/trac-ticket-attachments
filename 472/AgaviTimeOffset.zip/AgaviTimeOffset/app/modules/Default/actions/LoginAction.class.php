<?php

class Default_LoginAction extends AgaviAction
{
	public function execute(AgaviRequestDataHolder $rd)
	{
		// remove this execute() method and create executeRead() and executeWrite() methods or equivalents
		throw new Exception('LoginAction is not yet implemented. This is only an empty stub Action that serves as a reminder for you to do this :)');
	}

	public function getDefaultViewName()
	{
		return 'Success';
	}
}

?>