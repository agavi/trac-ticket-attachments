<?php

class Default_SecureAction extends AgaviAction
{
	public function getDefaultViewName()
	{
		return 'Success';
	}
}

?>