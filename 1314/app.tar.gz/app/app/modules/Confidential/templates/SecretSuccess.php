<p><?php echo $tm->_('You found the secret!', 'default.Login'); ?></p>
