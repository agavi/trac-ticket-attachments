Agavi domyślnie pracuje w trybie debugowania, co znaczy, że przy każdym żądaniu
parsuje ponownie pliki konfiguracyjne. Gdy ma to miejsce możesz zauważyć 
wolniejsze ładowanie strony. Tryb debufowania powinien być zostać jeśli 
planujesz bazować na tej instalacji. W przeciwnym wypadku możesz go wyłączyć.

<br/><br/>

<strong>Rada:</strong> Ręczne usuwanie plików i folderów z buforu z katalogu 
cache Agavi jest w porządku.

<br/><br/>

<strong>Rada:</strong> Jeśli pracujesz z wyłączonym trybem debufowania wiele 
Twoich błędów może pozostawać w zbuforowanych plikach konfiguracyjnych. Dlatego 
też bardzo zalecane jest zachowanie trybu debugowania dopóki Twoja aplikacja nie
osiągnie pełnej funkcjonalności.