<?php

class Disabled_IndexSuccessView extends AgaviSampleAppDisabledBaseView
{
	public function executeHtml(AgaviRequestDataHolder $rd)
	{
		$this->setupHtml($rd);

		// set the title
		$this->setAttribute('_title', 'Index Action');
	}
}

?>