<?php

/**
 * The base model from which all CacheMe module models inherit.
 */
class ProjectCacheMeBaseModel extends ProjectBaseModel
{

}

?>