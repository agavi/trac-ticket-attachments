<?php

/**
 * The base view from which all CacheMe module views inherit.
 */
class ProjectCacheMeBaseView extends ProjectBaseView
{

}

?>