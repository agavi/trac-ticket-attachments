<?php

/**
 * The base action from which all CacheMe module actions inherit.
 */
class ProjectCacheMeBaseAction extends ProjectBaseAction
{

}

?>